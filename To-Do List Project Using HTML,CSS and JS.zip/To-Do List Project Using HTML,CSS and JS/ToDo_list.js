
let addtolist=document.getElementById("addToYourList");

addtolist.addEventListener("click" ,function(){
    add_checkbox_and_ClearAllCompleted();
});


function add_checkbox_and_ClearAllCompleted()
{
    if(document.getElementById("input_Task").value!="" || checkbox.checked)
    {
        //-----------------------CheckBox-----------------------------
        var checkbox = document.createElement('input');
        checkbox.setAttribute('type', 'checkbox');
        checkbox.style.border = '1px solid black';


        //--------------TEXT NODE CODE & APPENDING NODES (CHECKBOX , TEXT) WITH DIV-------------
        //store Entered Task Text by user in var and empty the input field
        let task_text=document.getElementById("input_Task").value;
        document.getElementById("input_Task").value="";

        //create H1 tag store input value in it and addd some styling
        let textElement=document.createElement('h5');
        textElement.textContent=task_text;
        textElement.style.border = '1px solid black';
        textElement.style.padding='5px'
        //textElement.style.backgroundColor='black';
        textElement.style.color='black';
        textElement.style.marginLeft='5px';
        textElement.style.marginBottom='5px';

        //create div & Appending text and Checkbox with div
        let container=document.createElement('div');
        container.style.display="flex";
        container.appendChild(checkbox);
        container.appendChild(textElement);

        //-----------LINE BREAK------------------------------------
        //for adding break between two Checkboxes
        let break_=document.createElement('br');    
        container.appendChild(break_);
        container.appendChild(break_);

        //------------------------PUT LINE WHEN CHECK CHECBOX & VICEVERSA-------------
        //delete checkbox text(put horizontal line on text after checking the check box)
        checkbox.addEventListener("click" , function(){
            add_horizontalLine(textElement);
            });
        function add_horizontalLine(textElement)
        {   

            let deleteTag = textElement.querySelector('del');
            // Create del element if not already present
            if (!deleteTag)
            {
                let deleteTag=document.createElement('del');
                deleteTag.innerHTML=textElement.innerHTML;
                textElement.innerHTML="";
                textElement.appendChild(deleteTag);
            }
            else
            {
                if (checkbox.checked)
                {
                    deleteTag.style.textDecoration = 'line-through';
                } 
                else 
                {
                    deleteTag.style.textDecoration = 'none';
                }
            }
        }

       
        
        //------------------DOT BUTTONS-------------------------------
        // create dotButtons and append it with checkbox
        let dot_buttons=document.createElement('button');
        textElement.appendChild(dot_buttons);
        container.appendChild(dot_buttons);

        Object.assign(dot_buttons.style, {
            backgroundColor: 'transparent',
            border: 'none',
            cursor: 'pointer',
            position: 'relative',
            padding: '10px'
        });

        for(let i=0;i<=2;i++)
        {
            let dot =document.createElement('div');
            Object.assign(dot.style,{
            width: '4px',
            height: '4px',
            backgroundColor: 'black',
            borderRadius: '50%',
            margin: '2px '
            });
            dot_buttons.appendChild(dot);
        }

        //----------------------------------DELETE ICON-----------------------------------
        //create del button and append it with dot buttons
        let deleteicon=document.createElement('i');
        deleteicon.className='material-icons';
        deleteicon.innerHTML='&#xe872;';  // &#xe872; is unicode of del icon
        deleteicon.style.display='none';
        deleteicon.style.color='red';
        deleteicon.style.marginLeft='10px';
        deleteicon.style.marginTop='-30px';
        dot_buttons.appendChild(deleteicon);
        dot_buttons.addEventListener("click"  , function() {
            showDelButton(deleteicon);
        });
        function showDelButton(deleteicon)
        {

            if(deleteicon.style.display==='none')
            {
              deleteicon.style.display='block';
            }
            else
            {
               deleteicon.style.display='none'
            }
        }
        //--------------Remove Checkbox when user click on del icon----------------
        deleteicon.addEventListener("click" ,function()
        {
            delete_checkbox();
        });
        function delete_checkbox()
        {
            Parent_.removeChild(container);
        }


        //---------------clear All Completed Task-----------------------
        let clearAllcompleted=document.getElementById("clearCompleted");
        clearAllcompleted.addEventListener("click",function(){
            clearAllCompletedTasks();
        });
        function clearAllCompletedTasks()
        {
            if(checkbox.checked)
            {
                Parent_.removeChild(container);
            }
        }


        //-----------------appending all tags with main div--------------
        let Parent_=document.getElementById("checkbox_div");
        Parent_.appendChild(container);
    }
    else
    {
        //------ IF INPUT FIELD IS EMPTY 1ST WRITE IN IT---------------
        alert("Please Enter Task");
    }
}